#include <iostream>
#include <string>
#include "mono.h"

//class boardView
//{
//	private:
//		string property;
//		int location;
//
//	public:
//
//		string getProperty()
//		{
//			return property;
//		}
//
//		int getLocation()
//		{
//			return location;
//		}
//
//		void setProperty(string property)
//		{
//			this.property = property;
//		}
//
//		void setLocation(int location)
//		{
//			this.location = location;
//		}
//
//}


