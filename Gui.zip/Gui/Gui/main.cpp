//
//  main.cpp
//  Gui
//
//  Created by Harsh Patel on 4/1/17.
//  Copyright © 2017 Harsh Patel. All rights reserved.
//

#include <SFML/Graphics.hpp>
#include <SFML/Graphics/Text.hpp>
#include <SFML/Graphics/Font.hpp>
#include <iostream>
#include "Animation.h"
#include <string>

using namespace sf;
using namespace std;

int main(int argc, const char * argv[]) {
    
    
    //creates the window that lopads the GUI
    RenderWindow app(VideoMode(2030, 1600), "Monopoly" );
    
    //if you want to create rectangles this is an example of it
//    RectangleShape rec(Vector2f(100, 100));
   
    app.setFramerateLimit(60);
    
    
    //font variable to hold font for the property text
    Font font;
    
    //loads the font
    if(!font.loadFromFile("/Users/harsh/Desktop/Gui/Gui/8-BIT WONDER.TTF")){
    
        cout<<"error"<<endl;
    
    
    }
    
    
    //font variable to hold font for the player/budget text
    Font font2;
    
    //loads the font
    if(!font2.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Arial.ttf")){
        
        cout<<"error"<<endl;
        
    }
    
    
    
    //Text is a variable that holds the desired strings to display on the GUI
    Text playerName;
    Text playerName2;
    Text playerName3;
    Text playerName4;
    
    Text budget;
    Text budget2;
    Text budget3;
    Text budget4;

    Text propertiesText;
    
    
    //use this varibale to store input from the cosole and use the setString method which is shown on line 82 to set a string to the Text varables (they only accept strings)
    string input = "";
    
    //the methods for Text speak for themselves as to what thet do
    
    playerName.setCharacterSize(40);
    playerName.setFillColor(Color::Color(62, 70, 255, 255));
    playerName.setFont(font2);
    playerName.setString("Player: Harsh" + input);
    budget.setCharacterSize(35);
    budget.setFillColor(Color::Color(62, 70, 255, 255));
    budget.setFont(font2);
    budget.setString("Budget: $1000");
    
    playerName2.setCharacterSize(40);
    playerName2.setFillColor(Color::Color(255, 29, 29, 255));
    playerName2.setFont(font2);
    playerName2.setString("Player: Yasir" + input);
    budget2.setCharacterSize(35);
    budget2.setFillColor(Color::Color(255, 29, 29, 255));
    budget2.setFont(font2);
    budget2.setString("Budget: $1000");
    
    playerName3.setCharacterSize(40);
    playerName3.setFillColor(Color::Color(0, 151, 18, 255));
    playerName3.setFont(font2);
    playerName3.setString("Player: Dominic" + input);
    budget3.setCharacterSize(35);
    budget3.setFillColor(Color::Color(0, 151, 18, 255));
    budget3.setFont(font2);
    budget3.setString("Budget: $1000");
    
    playerName4.setCharacterSize(40);
    playerName4.setFillColor(Color::Color(134, 21, 176, 255));
    playerName4.setFont(font2);
    playerName4.setString("Player: Daniel" + input);
    budget4.setCharacterSize(35);
    budget4.setFillColor(Color::Color(134, 21, 176, 255));
    budget4.setFont(font2);
    budget4.setString("Budget: $1000");
    
    

    
    
    
    propertiesText.setCharacterSize(25);
    propertiesText.setFillColor(Color::Blue);
    propertiesText.setFont(font);
    propertiesText.setString("Properties Owned");

    
    //these variables will hold the position of the player on the tile. Tile starts at Go and is value 0, tile 1 is mediterannean avenue, tile 2 is baltic avenue.....etc.
    //increase the tilecounter+=dieValue (if you want to). I made 4 because 1 for each player. You guys can decide how you wanna do it
    int tileCounter = 0;
//    int tileCounter2 = 0;
//    int tileCounter3 = 0;
//    int tileCounter4 = 0;
    
    
    //Texture holds the value for each image
    //board texture
    Texture board;
    
    
    //all the pieces textures
    Texture robot;
    Texture Car;
    Texture Dog;
    Texture Iron;
    Texture Phone;
    Texture PotOfGold;
    Texture Ship;
    Texture Thimble;
    
    //textures for those sexy vertical and horizonal lines
    Texture vLine;
    Texture hLine;
    
    //all the tiles textures
    Texture tile0;
    Texture tile1;
    Texture tile2;
    Texture tile3;
    Texture tile4;
    Texture tile5;
    Texture tile6;
    Texture tile7;
    Texture tile8;
    Texture tile9;
    Texture tile10;
    Texture tile11;
    Texture tile12;
    Texture tile13;
    Texture tile14;
    Texture tile15;
    Texture tile16;
    Texture tile17;
    Texture tile18;
    Texture tile19;
    Texture tile20;
    Texture tile21;
    Texture tile22;
    Texture tile23;
    Texture tile24;
    Texture tile25;
    Texture tile26;
    Texture tile27;
    Texture tile28;
    Texture tile29;
    Texture tile30;
    Texture tile31;
    
    
    //all the property textures
    Texture prop1;
    Texture prop2;
    Texture prop3;
    Texture prop4;
    Texture prop5;
    Texture prop6;
    Texture prop7;
    Texture prop8;
    Texture prop9;
    Texture prop10;
    Texture prop11;
    Texture prop12;
    Texture prop13;
    Texture prop14;
    Texture prop15;
    Texture prop16;
    Texture prop17;
    Texture prop18;
    Texture prop19;
    Texture prop20;
    Texture prop21;
    Texture prop22;
    

    
    
    //loading all the pieces
    robot.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Robot.png");
    Car.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Car.png");
    Dog.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Dog.png");
    Iron.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Iron.png");
    Phone.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Phone.png");
    PotOfGold.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Pot of Gold.png");
    Ship.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Ship.png");
    Thimble.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Thimble.png");


    //loading all textures
    board.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Monopoly Board.png");
    vLine.loadFromFile("/Users/harsh/Desktop/Gui/Gui/vertical line.png");
    hLine.loadFromFile("/Users/harsh/Desktop/Gui/Gui/horizontal line.png");
    tile0.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Go.png");
    tile1.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Mediterranian Avenue.png");
    tile2.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Baltic Avenue.png");
    tile3.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Income Tax.png");
    tile4.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Oriental Avenue.png");
    tile5.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Community Chest1.png");
    tile6.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Vermont Avenue.png");
    tile7.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Connecticut Avenue.png");
    tile8.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Jail.png");
    tile9.loadFromFile("/Users/harsh/Desktop/Gui/Gui/St Charles Place.png");
    tile10.loadFromFile("/Users/harsh/Desktop/Gui/Gui/States Avenue.png");
    tile11.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Virginia Avenue.png");
    tile12.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Chance1.png");
    tile13.loadFromFile("/Users/harsh/Desktop/Gui/Gui/St James Place.png");
    tile14.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Tennessee Avenue.png");
    tile15.loadFromFile("/Users/harsh/Desktop/Gui/Gui/New York Avenue.png");
    tile16.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Free Parking.png");
    tile17.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Kentucky Avenue.png");
    tile18.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Indiana Avenue.png");
    tile19.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Illinois Avenue.png");
    tile20.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Community Chest2.png");
    tile21.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Atlantic Avenue.png");
    tile22.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Ventor Avenue.png");
    tile23.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Marvin Gardens.png");
    tile24.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Go To Jail.png");
    tile25.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Pacific Avenue.png");
    tile26.loadFromFile("/Users/harsh/Desktop/Gui/Gui/North Carolina Avenue.png");
    tile27.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Pennsylvania Avenue.png");
    tile28.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Luxury Tax.png");
    tile29.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Park Place.png");
    tile30.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Chance2.png");
    tile31.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Boardwalk.png");
    
    
    //loading all the properties
    prop1.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Mediterranian Avenue Label.png");
    prop2.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Atlantic Avenue Label.png");
    prop3.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Boardwalk Label.png");
    prop4.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Connecticut Avenue Label.png");
    prop5.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Illinois Avenue Label.png");
    prop6.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Indiana Avenue Label.png");
    prop7.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Baltic Avenue Label.png");
    prop8.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Kentucky Avenue Label.png");
    prop9.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Marvin Gardens Label.png");
    prop10.loadFromFile("/Users/harsh/Desktop/Gui/Gui/New York Avenue Label.png");
    prop11.loadFromFile("/Users/harsh/Desktop/Gui/Gui/North Carolina Ave Label.png");
    prop12.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Oriental Avenue Label.png");
    prop13.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Park Place Label.png");
    prop14.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Pennsylvania Avenue Label.png");
    prop15.loadFromFile("/Users/harsh/Desktop/Gui/Gui/St Charles Place Label.png");
    prop16.loadFromFile("/Users/harsh/Desktop/Gui/Gui/St James Place Label.png");
    prop17.loadFromFile("/Users/harsh/Desktop/Gui/Gui/States Avenue Label.png");
    prop18.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Tennessee Avenue Label.png");
    prop19.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Ventor Avenue Label.png");
    prop20.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Vermont Label.png");
    prop21.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Virginia Avenue Label.png");
    prop22.loadFromFile("/Users/harsh/Desktop/Gui/Gui/Pacific Avenue Label.png");


    
    
    

    //all the textures in a nice array
    Texture array [32] = {tile0, tile1, tile2, tile3, tile4, tile5, tile6, tile7, tile8, tile9, tile10, tile11, tile12, tile13, tile14, tile15, tile16, tile17, tile18, tile19, tile20, tile21, tile22, tile23, tile24, tile25, tile26, tile27, tile28, tile29, tile30, tile31};
    
    
    //all the properties in a vector (shouldve done the textures in a vector too but forgot they existed at the time so oh well)
    
    vector <Texture> propTextures;
    propTextures.push_back(prop1);
    propTextures.push_back(prop2);
    propTextures.push_back(prop3);
    propTextures.push_back(prop4);
    propTextures.push_back(prop5);
    propTextures.push_back(prop6);
    propTextures.push_back(prop7);
    propTextures.push_back(prop8);
    propTextures.push_back(prop9);
    propTextures.push_back(prop10);
    propTextures.push_back(prop11);
    propTextures.push_back(prop12);
    propTextures.push_back(prop13);
    propTextures.push_back(prop14);
    propTextures.push_back(prop15);
    propTextures.push_back(prop16);
    propTextures.push_back(prop17);
    propTextures.push_back(prop18);
    propTextures.push_back(prop19);
    propTextures.push_back(prop20);
    propTextures.push_back(prop21);
    propTextures.push_back(prop22);
    
    


    
    

    //The Sprite variable has textures object as you can (board) (tile0)
    
    //You have to turn the textures into sprites in order to draw them on the screen, move them around, scale them, or anything your heart desires.
    
    Sprite background (board);
    
    Sprite robotPiece(robot);
    Sprite carPiece (Car);
    Sprite dogPiece (Dog);
    Sprite ironPiece (Iron);
    Sprite phonePiece (Phone);
    Sprite potOfGoldPiece (PotOfGold);
    Sprite shipPiece (Ship);
    Sprite thimblePiece (Thimble);
    
    
    Sprite verticalLine(vLine);
    Sprite horizontalLine(hLine);
    Sprite secHorizontalLine(hLine);
    
    vector <Sprite> liveTileTextures;    //holds all the tiles in a Sprite vector. Use this information to dynamically update the tiles on the screen in the live tile section on the upper right
    vector <Sprite> property;            //holds all the properties in a sprite vector. Use this information to dynamically add or remove properties on/from the screen
    
    
    
    //puts all the property textures in the property sprite
    for(int i =0; i<propTextures.size(); i++){
        
        Sprite newProperty;
        newProperty.setTexture(propTextures[i]);
        
        property.push_back(newProperty);
    }
    
    //puts all the tile textures in the liveTileTexture sprite
    for(int i =0; i!=32; i++){
    
        Sprite newTile;
        newTile.setTexture(array[i]);
        
        liveTileTextures.push_back(newTile);

    }
    
    

    
    
    //moving objects
    
    //you guys are smart so i thing you can figure it out. The values inside the .move method is based on pixels. P.S. The total pixels the window is made up of is (2030, 1600) which is showcased in line 26
    
    liveTileTextures[tileCounter].move(1612, 0);
    verticalLine.move(1601,0);
    
    horizontalLine.move(1610,421);
    secHorizontalLine.move(1610,1308);
    
    
    //I leave the movement of the pieces to you smart guys
    
    robotPiece.scale(1.5, 1.5);
    robotPiece.move(40, 1280);
    carPiece.move(40,1450);
    dogPiece.move(40,1450);
    ironPiece.move(40,1450);
    phonePiece.move(40,1450);
    potOfGoldPiece.move(40,1450);
    shipPiece.move(40,1450);
    thimblePiece.move(40,1450);
    
    
    
    
    propertiesText.move(1627, 430);
    property[1].move(1620, 480);    //make sure you change the index for this otherwise it wont move properly. So if you change the index in the .draw method for property it wont be in the right position since only index one is moved.
    
    
    playerName.move(1616, 1311);
    budget.move(1616,1345);
    
    playerName2.move(1616, 1382);
    budget2.move(1616, 1418);
    
    playerName3.move(1616, 1455);
    budget3.move(1616,1489);
    
    playerName4.move(1616, 1523);
    budget4.move(1616, 1557);

    board.setSmooth(true);
    
    
    //this is WHERE ALL THE LOGIC WILL GO THAT NEEDS TO BE REPEATED. This while is responsible for maintaining/loading the gui on the screen at all times
    while(app.isOpen()){
    
    

        Event e;
        while(app.pollEvent(e)){
        
            if(e.type==Event::Closed){
            
                app.close();
            
            }

        }
        
        
        //this line of code is an example of how key presses can be used but i don't think we will need it. This is just for reference
//        if (sf::Keyboard::isKeyPressed(sf::Keyboard::A))
//        {
//            // left key is pressed: move our character
//            robotPiece.move(1, 0);
//        }
        
        
        
        

        //ALL THE REPEATED LOGIC WILL GO HERE!!!!!!!!!!!!!!!
       /*
        
        
        
        
        
        
        
        
        
        up until the end of the while loop is all up to your logic. Know when to draw!!!!!!!!!! */
        
        
        // .draw function is responsible for actually "drawing" or displaying our objects on the window. SO MAKE SURE YOU KNOW WHAT TO DRAW AND WHEN!!!!!!!!!!!!!
        app.draw(background);
        app.draw(liveTileTextures[tileCounter]);
        app.draw(verticalLine);
        app.draw(horizontalLine);
        app.draw(secHorizontalLine);
        app.draw(playerName);
        app.draw(budget);
        app.draw(propertiesText);
        app.draw(playerName2);
        app.draw(budget2);
        app.draw(playerName3);
        app.draw(budget3);
        app.draw(playerName4);
        app.draw(budget4);
        app.draw(property[1]);     //change index for this to dynamically update the property and so that it can be moves in the right position. May need to be put in an if statement if we have to check what people have and dont
       
        app.draw(robotPiece);
        
//uncomment to draw the pieces on screen. Should be around go. If not check the .move method for piece.
        
//        app.draw(carPiece);
//        app.draw(shipPiece);
//        app.draw(potOfGoldPiece);
//        app.draw(thimblePiece);
//        app.draw(phonePiece);
//        app.draw(dogPiece);
//        app.draw(ironPiece);
        
        
        
        
        
        
        app.display();             //this opens the window that displays all our drawings
        
       
        app.clear(sf::Color(216, 255, 232, 45));      //This is responible for changing the background of the window
    
    }
   
    
    }
    
